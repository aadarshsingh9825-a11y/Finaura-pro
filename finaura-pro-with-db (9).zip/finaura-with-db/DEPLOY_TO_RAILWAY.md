# 🚀 Deploy Finaura Pro to Railway (Free)

## What you'll get
A live URL like `https://finaura-pro.up.railway.app` that anyone can open.
Then link your Wix "Join Finaura" button to that URL.

---

## Step 1 — Create a GitHub account (if you don't have one)
Go to https://github.com and sign up free.

---

## Step 2 — Upload the project to GitHub

1. Go to https://github.com/new
2. Name it `finaura-pro`, set to **Public**, click **Create repository**
3. On the next page click **uploading an existing file**
4. Drag ALL these files into the window:
   - `server.py`
   - `tradehub-complete.html`
   - `finaura-logo.jpeg`
   - `requirements.txt`
   - `Procfile`
   - `railway.json`
5. Click **Commit changes**

---

## Step 3 — Deploy on Railway

1. Go to https://railway.app
2. Click **Login with GitHub** → authorize it
3. Click **New Project** → **Deploy from GitHub repo**
4. Select your `finaura-pro` repository
5. Railway will automatically detect and deploy it (takes ~2 minutes)
6. Click on the deployment → **Settings** → **Networking** → **Generate Domain**
7. You'll get a URL like: `https://finaura-pro-production.up.railway.app`

---

## Step 4 — Add a Volume (so the database persists)

1. In your Railway project, click **+ New** → **Volume**
2. Mount path: `/data`
3. Click **Add**

This makes sure user accounts and portfolios are never lost when Railway restarts.

---

## Step 5 — Link your Wix button

1. Open your Wix website editor
2. Click the **"Join Finaura"** button
3. Click **Link** → **Web Address**
4. Paste your Railway URL (e.g. `https://finaura-pro-production.up.railway.app`)
5. Set to **Open in new tab**
6. **Publish** your Wix site

---

## Done! 🎉

Anyone who clicks "Join Finaura" on your Wix site will be taken directly
to the live trading platform where they can register, log in, and trade.

---

## Free tier limits (Railway)
- $5 free credit per month (~500 hours of runtime)
- Enough for a hobby/portfolio project
- Upgrade anytime if you need more

## Notes
- The SQLite database is stored in `/data` volume — persists forever
- Live prices from Yahoo Finance refresh every 60 seconds
- All user accounts and portfolios are kept permanently
