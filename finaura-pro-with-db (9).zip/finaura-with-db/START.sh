#!/bin/bash
echo ""
echo "============================================================"
echo "  FINAURA PRO - Paper Trading Platform"
echo "============================================================"
echo ""

# Install Flask if needed
pip3 install flask -q 2>/dev/null || pip install flask -q 2>/dev/null

# Run
python3 server.py || python server.py
