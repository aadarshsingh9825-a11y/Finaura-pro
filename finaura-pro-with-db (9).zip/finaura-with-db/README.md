# 🚀 Finaura Pro — Paper Trading Platform

## Quick Start

**Windows:** Double-click `START.bat`  
**Mac/Linux:** Run `bash START.sh` or `python3 server.py`

Then open: **http://localhost:5000**

---

## How It Works

### 🔐 User Accounts
- Register a username + password → **saved permanently** in `finaura_users.db`
- Multiple users can have separate accounts on the same machine
- Passwords are hashed (SHA-256) — never stored in plain text

### 💰 Portfolio (Session-Based Reset)
- Every time the server starts, **all portfolios reset to $25,000**
- User credentials are **never** deleted — only trading data resets
- This is intentional for a fresh paper-trading session each time

### 📊 Features
- Buy & sell 26+ stock tickers with simulated prices
- Portfolio tracking with real-time P&L
- Watchlist synced to database
- Limit orders
- Market scanner (gainers/losers/most active)
- Transaction history
- Advanced analytics and benchmarking

---

## Files

| File | Purpose |
|------|---------|
| `server.py` | Flask backend + SQLite database + REST API |
| `tradehub-complete.html` | Rich trading UI (served by server) |
| `finaura_users.db` | Auto-created user accounts database |
| `START.bat` | Windows one-click launcher |
| `START.sh` | Mac/Linux launcher |

---

## Requirements
- Python 3.8+
- Flask (auto-installed on first run)

*Finaura Pro — Smart Money. Smarter Future.*
